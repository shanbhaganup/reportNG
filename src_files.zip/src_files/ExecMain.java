package src_files;

import java.util.ArrayList;
import java.util.Scanner;

public class ExecMain {

	ArrayList<BANK> accounts = new ArrayList<BANK>();
	
	public BANK selectBank(Scanner jin)
	{
		BANK b=null;
		String choice, accNum;
		long num;
		boolean bankSelect=false;
		System.out.println("\nSELECT THE BANK : ");
		do
		{
			System.out.println("\n1. SBI, Bangalore, Karnataka");
			System.out.println("2. ICICI, Hyderabad, Andhra Pradesh");
			System.out.println("3. AXIS Chennai, Tamilnadu");
			System.out.print("ENTER CHOICE : ");
			choice = jin.nextLine();
			switch(choice)
			{
				case "1": 	System.out.print("ENTER ACCOUNT-NUMBER : ");
							accNum = jin.nextLine();
							try{
								num = Long.parseLong(accNum);
							}catch (Exception e)
							{
								System.out.println("ACCOUNT-NO CAN CONTAIN ONLY NUMERIC DATA! TRY AGAIN!");
								bankSelect = false;
								continue;
							}
							b = new SBISavingsAccount("Whitefield","SBIS5600009","Bangalore, Karnataka",accNum,300.0);
							bankSelect=true;
						break;

				case "2": 	System.out.print("ENTER ACCOUNT-NUMBER : ");
							accNum = jin.nextLine();
							try{
								num = Long.parseLong(accNum);
							}catch (Exception e)
							{
								System.out.println("ACCOUNT-NO CAN CONTAIN ONLY NUMERIC DATA! TRY AGAIN!");
								bankSelect = false;
								continue;
							}
							b = new ICICISavingsAccount("Madhapur","ICICI563124","Hyderabad, Andhra Pradesh",accNum,300.0);
							bankSelect=true;
						break;

				case "3": 	System.out.print("ENTER ACCOUNT-NUMBER : ");
							accNum = jin.nextLine();
							try{
								num = Long.parseLong(accNum);
							}catch (Exception e)
							{
								System.out.println("ACCOUNT-NO CAN CONTAIN ONLY NUMERIC DATA! TRY AGAIN!");
								bankSelect = false;
								continue;
							}
							b = new AXISSavingsAccount("Kumaran Nagar","AXIS5803269","Chennai, Tamil Nadu",accNum,300.0);
							bankSelect=true;
						break;
				default: System.out.println("WRONG CHOICE ! TRY AGAIN!");
						 bankSelect=false;
			}
		}while(!bankSelect);
		return b;
	}
	
	public void BankTransaction(Scanner jin)
	{
		BANK bankAcc;
		SBISavingsAccount sbi = new SBISavingsAccount();
		ICICISavingsAccount icici = new ICICISavingsAccount();
		System.out.println("\nSELECT OPERATION TO BE PERFORMED : ");
		String choice;
		do
		{
				System.out.println("\n1. CREATE ACCOUNT");
				System.out.println("2. DEPOSIT AMOUNT");
				System.out.println("3. WITHDRAW AMOUNT");
				System.out.println("4. CHECK BALANCE");
				System.out.println("5. CALCULATE INTEREST(One Year) FOR CURRENT BALANCE");
				System.out.println("6. EXIT");
				System.out.print("ENTER CHOICE : ");
				choice = jin.nextLine();
				switch(choice)
				{
					case "1": 	bankAcc = selectBank(jin);
								accounts.add(bankAcc);
							break;
					case "2": 	bankAcc = selectBank(jin);
								if(accounts.contains(bankAcc))
								{
									int i = accounts.indexOf(bankAcc);
									BANK b =accounts.get(i);
									System.out.print("ENTER AMOUNT : ");
									double amt=0.0;
									try{
									amt = Double.parseDouble(jin.nextLine());
									if(amt<=0.0) throw new Exception();
									}catch(NumberFormatException e){
										System.out.println("AMOUNT IS NUMERIC! TRY AGAIN!");
										continue;
									}
									catch(Exception e)
									{
										System.out.println("DEPOSIT AMOUNT SHOULD BE GREATER THAN ZERO!");
										continue;
									}
									if(b.getClass().getName().equals(sbi.getClass().getName()))
									{
										SBISavingsAccount sAcc =(SBISavingsAccount)b;
										sAcc.deposit(amt);
									}
									else if(b.getClass().getName().equals(icici.getClass().getName()))
									{
										ICICISavingsAccount sAcc =(ICICISavingsAccount)b;
										sAcc.deposit(amt);
									}
									else
									{
										AXISSavingsAccount sAcc =(AXISSavingsAccount)b;
										sAcc.deposit(amt);
									}	
								}
								else
									System.out.println("NO SUCH ACCOUNT EXISTS!");
							break;
					case "3": 	bankAcc = selectBank(jin);
								if(accounts.contains(bankAcc))
								{
										int i = accounts.indexOf(bankAcc);
										BANK b =accounts.get(i);
										System.out.print("ENTER AMOUNT : ");
										double amt=0.0;
										try{
										amt = Double.parseDouble(jin.nextLine());
										if(amt<=0.0) throw new Exception();
										}catch(NumberFormatException e){
											System.out.println("AMOUNT IS NUMERIC! TRY AGAIN!");
											continue;
										}
										catch(Exception e)
										{
											System.out.println("WITHDRAWAL AMOUNT SHOULD BE GREATER THAN ZERO AND LESS THAN THE CURRENT BALANCE!");
											continue;
										}
						
										if(b.getClass().getName().equals(sbi.getClass().getName()))
										{
											SBISavingsAccount sAcc =(SBISavingsAccount)b;
											try{
											if(amt>sAcc.availBalance()) throw new Exception();
											}catch (Exception e){
												System.out.println("WITHDRAWAL AMOUNT SHOULD BE LESS THAN OR EQUAL TO THE CURRENT BALANCE!");
												continue;
											}
											sAcc.withdraw(amt);
										}
										else if(b.getClass().getName().equals(icici.getClass().getName()))
										{
											ICICISavingsAccount sAcc =(ICICISavingsAccount)b;
											try{
											if(amt>sAcc.availBalance()) throw new Exception();
											}catch (Exception e){
												System.out.println("WITHDRAWAL AMOUNT SHOULD BE LESS THAN OR EQUAL TO THE CURRENT BALANCE!");
												continue;
											}
											sAcc.withdraw(amt);
										}
										else
										{
											AXISSavingsAccount sAcc =(AXISSavingsAccount)b;
											try{
											if(amt>sAcc.availBalance()) throw new Exception();
											}catch (Exception e){
												System.out.println("WITHDRAWAL AMOUNT SHOULD BE LESS THAN OR EQUAL TO THE CURRENT BALANCE!");
												continue;
											}
											sAcc.withdraw(amt);
										}	
								}
								else
									System.out.println("NO SUCH ACCOUNT EXISTS!");
							break;
					case "4": 	bankAcc = selectBank(jin);
								if(accounts.contains(bankAcc))
								{
									int i = accounts.indexOf(bankAcc);
									BANK b =accounts.get(i);
									if(b.getClass().getName().equals(sbi.getClass().getName()))
									{
										SBISavingsAccount sAcc =(SBISavingsAccount)b;
										System.out.println("AVAILABLE BALANCE \t:\t "+sAcc.availBalance());
									}
									else if(b.getClass().getName().equals(icici.getClass().getName()))
									{
										ICICISavingsAccount sAcc =(ICICISavingsAccount)b;
										System.out.println("AVAILABLE BALANCE \t:\t "+sAcc.availBalance());
									}
									else
									{
										AXISSavingsAccount sAcc =(AXISSavingsAccount)b;
										System.out.println("AVAILABLE BALANCE \t:\t "+sAcc.availBalance());
									}	
								}
								else
									System.out.println("NO SUCH ACCOUNT EXISTS!");
							break;
					case "5": 	bankAcc = selectBank(jin);
								if(accounts.contains(bankAcc))
								{
									int i = accounts.indexOf(bankAcc);
									BANK b =accounts.get(i);		
									if(b.getClass().getName().equals(sbi.getClass().getName()))
									{
										SBISavingsAccount sAcc =(SBISavingsAccount)b;
										System.out.println("1YR INTEREST ON CURRENT ACCOUNT \t:\t "+sAcc.calcInterest());
									}
									else if(b.getClass().getName().equals(icici.getClass().getName()))
									{
										ICICISavingsAccount sAcc =(ICICISavingsAccount)b;
										System.out.println("1YR INTEREST ON CURRENT ACCOUNT \t:\t "+sAcc.calcInterest());
									}
									else
									{
										AXISSavingsAccount sAcc =(AXISSavingsAccount)b;
										System.out.println("1YR INTEREST ON CURRENT ACCOUNT \t:\t "+sAcc.calcInterest());
									}	
								}
								else
									System.out.println("NO SUCH ACCOUNT EXISTS!");
							break;
				case "6": System.exit(0);break;
				default: System.out.println("WRONG CHOICE ! TRY AGAIN!");
				}
			}while(true);
	}
	
	public static void main(String[] args) 
	{
		Scanner jin = new Scanner(System.in);
		ExecMain m = new ExecMain();
		m.BankTransaction(jin);
	}
}
