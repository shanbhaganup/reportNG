package src_files;

abstract public class BANK {
	protected String BranchName, IFSCCode, Location;
	
	abstract protected String getLocation(); 
	abstract protected String getIFSCCode();
	abstract protected String getBranchName(); 
	
	abstract protected void setLocation(String Location);
	abstract protected void setIFSCCode(String IFSCCode);
	abstract protected void setBranchName(String BranchName);	
	@Override
	public abstract boolean equals(Object obj);
}
