package src_files;

abstract public class ICICI extends BANK
{
	static int InterestRate=7;
	ICICI(){}
	ICICI(String BranchName, String IFSCCode, String Location)
	{
		this.BranchName=BranchName;
		this.IFSCCode=IFSCCode;
		this.Location=Location;
	}
	protected String getLocation() {return Location;}
	protected String getIFSCCode() {return IFSCCode;}
	protected String getBranchName() {return BranchName;}
	
	protected void setLocation(String Location) {this.Location=Location;}
	protected void setIFSCCode(String IFSCCode) {this.IFSCCode=IFSCCode;}
	protected void setBranchName(String BranchName) {this.BranchName=BranchName;}
	@Override
	public abstract boolean equals(Object obj);
}

class ICICISavingsAccount extends ICICI
{
	protected double AccountBalance;
	protected String AccountNo;
	ICICISavingsAccount() {}
	ICICISavingsAccount(String BranchName, String IFSCCode, String Location,String AccountNo,double AccountBalance) 
	{
		super(BranchName,IFSCCode,Location);
		this.AccountBalance=AccountBalance;
		this.AccountNo=AccountNo;
	}
	protected String getAccountNumber(){return AccountNo;}
	protected double availBalance(){return AccountBalance;}
	protected void deposit(double amount)
	{
		AccountBalance+=amount;
		System.out.println(amount+"/- IS SUCCESSFULLY CREDITED TO THE ACCOUNT# "+AccountNo);
		System.out.println("BALANCE : "+AccountBalance);
	}
	protected void withdraw(double amount)
	{
		AccountBalance-=amount;
		System.out.println(amount+"/- IS SUCCESSFULLY DEBITED FROM THE ACCOUNT# "+AccountNo);
		System.out.println("BALANCE : "+AccountBalance);
	}
	protected void displayDetails()
	{
		System.out.println("ACCOUNT# \t:\t"+AccountNo);
		System.out.println("BRANCH \t:\t"+BranchName);
		System.out.println("IFSC# \t:\t"+IFSCCode);
		System.out.println("LOCATION \t:\t"+ Location);
		System.out.println("BALANCE \t:\t"+availBalance()+" /-");
	}
	protected int getRateOfInterest(){return InterestRate;}
	protected double calcInterest() {return ((AccountBalance*InterestRate)/100);}
	
	@Override
	public boolean equals(Object obj) 
	{
		if (this == obj)	return true;
		if (obj == null)	return false;
		if (getClass() != obj.getClass())	return false;
		ICICISavingsAccount other = (ICICISavingsAccount) obj;
		if (AccountNo == null) 
		{
			if (other.AccountNo != null)	return false;
		} 
		else if (!AccountNo.equals(other.AccountNo))
			return false;
		
		return true;
	}
	
}

class ICICISalaryAccount extends ICICISavingsAccount
{
	ICICISalaryAccount () {}
	ICICISalaryAccount (String BranchName, String IFSCCode, String Location,String AccountNo,double AccountBalance ) 
	{
		super(BranchName,IFSCCode,Location,AccountNo,AccountBalance);
	}
	protected void ZeroBalance()
	{
		System.out.println("Salary Account is an Zero Balance Account!\n"
				+""
				+"");
	}
	protected void HighInterestRate()
	{
		System.out.println("**** Diwali Dhamaka Offer ****\n"
				+"Exclusively For customers having salary account.\n"
				+"Interest rate of 11.5% on Fixed Deposits");
	}
	protected int getRateOfInterest(){return InterestRate;}
	protected double calcInterest() {return ((AccountBalance*InterestRate)/100);}
}

class ICICICurrentAccount{
	
}